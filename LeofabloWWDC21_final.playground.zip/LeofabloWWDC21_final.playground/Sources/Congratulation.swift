import Foundation
import UIKit
import PlaygroundSupport

public class congratulation : UIView {
    var frameWidth = 700
    var frameHeight = 500
    
    
    let quizbackground = UIImageView()
    let emblem = UIImageView()
    let congratulation = UIImageView()
    
    
    public init(scene: UIView){
        super.init(frame: CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight))
        setupUI()
    }
    
    public required init?(coder: NSCoder) {
        fatalError()
    }
    
    func setupUI(){
        
        // background
        quizbackground.image = UIImage(named: "backgroundQuiz.png")
        quizbackground.frame = CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight)
        quizbackground.contentMode = .scaleToFill
        quizbackground.alpha = 1
        self.addSubview(quizbackground)
        
        
        // ngasih welcome image font
        emblem.image = UIImage(named: "Emblem.png")
        emblem.frame = CGRect(x: 280, y: 230, width: 140, height: 140)
        // welcomeImage.center = CGPoint(x: frameWidth/2, y:frameHeight/2)
        emblem.contentMode = .scaleToFill
        self.addSubview(emblem)
        
        // ngasih font congratulation
        congratulation.image = UIImage(named: "congratulationfont.png")
        congratulation.frame = CGRect(x: 259, y: 130, width: 183, height: 77)
        congratulation.contentMode = .scaleToFill
        congratulation.alpha = 1
        self.addSubview(congratulation)
      
    }
    
    @objc func getStartedButtonPressed(_ sender: UIButton?){
        
 //       nextScreen()
    }
//
//    // button next ke introduction leo
//    func nextScreen(){
//        self.removeFromSuperview()
//        let welcomeView = introduction(scene: self)
//        PlaygroundPage.current.liveView = welcomeView
//    }
    
}

