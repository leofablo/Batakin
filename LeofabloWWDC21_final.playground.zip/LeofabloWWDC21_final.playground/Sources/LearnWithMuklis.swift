import Foundation
import UIKit
import PlaygroundSupport

public class learnwithmuklis : UIView {
    var frameWidth = 700
    var frameHeight = 500
    
    let leo = UIImageView()
    let mukliskanan = UIImageView()
    let bulatan = UIImageView()
    let awanleolearn = UIImageView()
    let letsGo = UIButton()
    
    public init(scene: UIView){
        super.init(frame: CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight))
        setupUI()
    }
    
    public required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupUI(){
    
        
        // ilustrasi leo
        leo.image = UIImage(named: "leo.png")
        leo.frame = CGRect(x: 41, y: 184, width: 244, height: 316)
        leo.contentMode = .scaleToFill
        leo.alpha = 1
        self.addSubview(leo)
        
        
        // ilustrasi muklis
        mukliskanan.image = UIImage(named: "muklislearn.png")
        mukliskanan.frame = CGRect(x: 481, y: 333, width: 136, height: 167)
        mukliskanan.contentMode = .scaleToFill
        mukliskanan.alpha = 1
        self.addSubview(mukliskanan)
        
        
        // bulatan
        bulatan.image = UIImage(named: "bulatan.png")
        bulatan.frame = CGRect(x: 200, y: 192, width: 40, height: 35)
        bulatan.contentMode = .scaleToFill
        bulatan.alpha = 1
        self.addSubview(bulatan)
        
        
        // awan leo learn
        awanleolearn.image = UIImage(named: "awanmuklislearn.png")
        awanleolearn.frame = CGRect(x: 245, y: 36, width: 290, height: 203)
        awanleolearn.contentMode = .scaleToFill
        awanleolearn.alpha = 1
        self.addSubview(awanleolearn)
        
        letsGo.setTitle("Let's Go", for: .normal)
        letsGo.frame = CGRect(x: 300, y: 350, width: 131, height: 44)
        //getStartedButton.center = CGPoint(x: frameWidth/2, y:frameHeight/2)
        letsGo.layer.cornerRadius = 20.0
        letsGo.backgroundColor = UIColor.black
        letsGo.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        letsGo.layer.shadowOpacity = 0.2
        letsGo.layer.cornerRadius = 20.0
        letsGo.layer.shadowOffset = CGSize(width: 0.0, height: 2.0)
        letsGo.addTarget(self, action: #selector(nextButtonPressed), for: .touchUpInside)
        self.addSubview(letsGo)
        
    }
    
    @objc func nextButtonPressed(_ sender: UIButton?){
        
        nextScreen()
    }

   // button next ke introduction leo 2
  func nextScreen() {
      self.removeFromSuperview()
       let learnwithmuklis = tablepanggilan(scene: self)
      PlaygroundPage.current.liveView = learnwithmuklis

        }

    
}

