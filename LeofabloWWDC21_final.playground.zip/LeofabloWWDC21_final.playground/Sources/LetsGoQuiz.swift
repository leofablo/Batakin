import Foundation
import UIKit
import PlaygroundSupport

public class letsgoquiz : UIView {
    var frameWidth = 700
    var frameHeight = 500
    
    let muklis = UIImageView()
    let bulatan = UIImageView()
    let awanletsgo = UIImageView()
    let nextButton = UIButton()
    
    public init(scene: UIView){
        super.init(frame: CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight))
        setupUI()
    }
    
    public required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupUI(){
    
        
        // ilustrasi leo
        muklis.image = UIImage(named: "muklisilustrasi.png")
        muklis.frame = CGRect(x: 50, y: 190, width: 257, height: 313)
        muklis.contentMode = .scaleToFill
        muklis.alpha = 1
        self.addSubview(muklis)
        
        // bulatan
        bulatan.image = UIImage(named: "bulatan.png")
        bulatan.frame = CGRect(x: 214, y: 190, width: 40, height: 35)
        bulatan.contentMode = .scaleToFill
        bulatan.alpha = 1
        self.addSubview(bulatan)
        
        
        // awan lets go
        awanletsgo.image = UIImage(named: "muklisletsgo.png")
        awanletsgo.frame = CGRect(x: 277, y: 41, width: 344, height: 257)
        awanletsgo.contentMode = .scaleToFill
        awanletsgo.alpha = 1
        self.addSubview(awanletsgo)
        

        nextButton.setTitle("Let's Go", for: .normal)
        nextButton.frame = CGRect(x: 300, y: 350, width: 131, height: 44)
        //getStartedButton.center = CGPoint(x: frameWidth/2, y:frameHeight/2)
        nextButton.layer.cornerRadius = 20.0
        nextButton.backgroundColor = UIColor.black
        nextButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        nextButton.layer.shadowOpacity = 0.2
        nextButton.layer.cornerRadius = 20.0
        nextButton.layer.shadowOffset = CGSize(width: 0.0, height: 2.0)
        nextButton.addTarget(self, action: #selector(nextButtonPressed), for: .touchUpInside)
        self.addSubview(nextButton)
        
    }
    
    @objc func nextButtonPressed(_ sender: UIButton?){
        
        nextScreen()
    }

   // button next ke introduction leo 2
  func nextScreen() {
      self.removeFromSuperview()
       let letsgoquiz = quizpertama(scene: self)
      PlaygroundPage.current.liveView = letsgoquiz


        
    }

    
}



