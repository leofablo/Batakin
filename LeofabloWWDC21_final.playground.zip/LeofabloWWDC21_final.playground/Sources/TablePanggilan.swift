import Foundation
import UIKit
import PlaygroundSupport

public class tablepanggilan : UIView {
    var frameWidth = 700
    var frameHeight = 500
    
    
    let nextButton = UIButton()
    let tablepanggilan = UIImageView()
    
    
    
    public init(scene: UIView){
        super.init(frame: CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight))
        setupUI()
    }
    
    public required init?(coder: NSCoder) {
        fatalError()
    }
    
    func setupUI(){
        
        // ngasih gorden
        tablepanggilan.image = UIImage(named: "tabelpanggilan.png")
        tablepanggilan.frame = CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight)
        tablepanggilan.contentMode = .scaleToFill
        tablepanggilan.alpha = 1
        tablepanggilan.backgroundColor = UIColor(patternImage: UIImage(named: "tabelpanggilan.png")!)
        self.addSubview(tablepanggilan)
        

        // next button
        nextButton.setTitle("Next", for: .normal)
        nextButton.frame = CGRect(x: 514, y: 427, width: 131, height: 44)
        //getStartedButton.center = CGPoint(x: frameWidth/2, y:frameHeight/2)
        nextButton.layer.cornerRadius = 20.0
        nextButton.backgroundColor = UIColor.black
        nextButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        nextButton.layer.shadowOpacity = 0.2
        nextButton.layer.cornerRadius = 20.0
        nextButton.layer.shadowOffset = CGSize(width: 0.0, height: 2.0)
        nextButton.addTarget(self, action: #selector(nextButtonPressed), for: .touchUpInside)
        self.addSubview(nextButton)
        
    }
    
    @objc func nextButtonPressed(_ sender: UIButton?){
        
        nextScreen()
    }
    
    // button next ke introduction leo
    func nextScreen(){
        self.removeFromSuperview()
        let tablepanggilan = leoasking(scene: self)
        PlaygroundPage.current.liveView = tablepanggilan

        
    }
    
}

