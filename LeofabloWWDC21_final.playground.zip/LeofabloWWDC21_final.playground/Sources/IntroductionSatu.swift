import Foundation
import UIKit
import PlaygroundSupport

public class introduction : UIView {
    var frameWidth = 700
    var frameHeight = 500
    
    
    let leo = UIImageView()
    let bulatan = UIImageView()
    let awanleo = UIImageView()
    let nextButton = UIButton()
    
    public init(scene: UIView){
        super.init(frame: CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight))
        setupUI()
    }
    
    public required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupUI(){
        
        // ilustrasi leo 1
        leo.image = UIImage(named: "leopng.png")
        leo.frame = CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight)
        leo.contentMode = .scaleToFill
        leo.alpha = 1
        self.addSubview(leo)
        
        
        // bulatan
        bulatan.image = UIImage(named: "bulatan.png")
        bulatan.frame = CGRect(x: 200, y: 192, width: 40, height: 35)
        bulatan.contentMode = .scaleToFill
        bulatan.alpha = 1
        self.addSubview(bulatan)
        
        
        // awan font
        awanleo.image = UIImage(named: "awanleo.png")
        awanleo.frame = CGRect(x: 300, y: 57, width: 306, height: 230)
        awanleo.contentMode = .scaleToFill
        leo.alpha = 1
        self.addSubview(awanleo)
        
        nextButton.setTitle("Next", for: .normal)
        nextButton.frame = CGRect(x: 514, y: 401, width: 131, height: 44)
        //getStartedButton.center = CGPoint(x: frameWidth/2, y:frameHeight/2)
        nextButton.layer.cornerRadius = 20.0
        nextButton.backgroundColor = UIColor.black
        nextButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        nextButton.layer.shadowOpacity = 0.2
        nextButton.layer.cornerRadius = 20.0
        nextButton.layer.shadowOffset = CGSize(width: 0.0, height: 2.0)
        nextButton.addTarget(self, action: #selector(nextButtonPressed), for: .touchUpInside)
        self.addSubview(nextButton)
        
    }
    
    @objc func nextButtonPressed(_ sender: UIButton?){
        
        nextScreen()
    }
    
   // button next ke introduction leo 2
  func nextScreen() {
      self.removeFromSuperview()
       let introduction = introleo2(scene: self)
      PlaygroundPage.current.liveView = introduction

        }

    
}


