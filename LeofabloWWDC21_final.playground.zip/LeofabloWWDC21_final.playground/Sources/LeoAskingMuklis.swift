import Foundation
import UIKit
import PlaygroundSupport

public class leoasking : UIView {
    var frameWidth = 700
    var frameHeight = 500
    
    let leoAsking = UIImageView()
    let mukliskanan = UIImageView()
    let bulatan = UIImageView()
    let bulatan2 = UIImageView()
    let awanLeoAsking = UIImageView()
    let awanMuklisAnswer = UIImageView()
    let nextButton = UIButton()
    
    public init(scene: UIView){
        super.init(frame: CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight))
        setupUI()
    }
    
    public required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupUI(){
    
        
        // ilustrasi leo
        leoAsking.image = UIImage(named: "leonanyamuklis.png")
        leoAsking.frame = CGRect(x: 28, y: 184, width: 256, height: 316)
        leoAsking.contentMode = .scaleToFill
        leoAsking.alpha = 1
        self.addSubview(leoAsking)
        
        
        // ilustrasi muklis
        mukliskanan.image = UIImage(named: "muklislearn.png")
        mukliskanan.frame = CGRect(x: 504, y: 333, width: 136, height: 167)
        mukliskanan.contentMode = .scaleToFill
        mukliskanan.alpha = 1
        self.addSubview(mukliskanan)
        
        
        // bulatan 1
        bulatan.image = UIImage(named: "bulatan.png")
        bulatan.frame = CGRect(x: 186, y: 190, width: 40, height: 35)
        bulatan.contentMode = .scaleToFill
        bulatan.alpha = 1
        self.addSubview(bulatan)
        
        // bulatan 2
        bulatan2.image = UIImage(named: "bulatandua.png")
        bulatan2.frame = CGRect(x: 538, y: 317, width: 25, height: 22)
        bulatan2.contentMode = .scaleToFill
        bulatan2.alpha = 1
        self.addSubview(bulatan2)
        
        
        // awan leo bertanya
        awanLeoAsking.image = UIImage(named: "awanleobertanya.png")
        awanLeoAsking.frame = CGRect(x: 191, y: 64, width: 267, height: 153)
        awanLeoAsking.contentMode = .scaleToFill
        awanLeoAsking.alpha = 1
        self.addSubview(awanLeoAsking)
        
        // awan muklis menjawab
        awanMuklisAnswer.image = UIImage(named: "awanmuklismenjawab.png")
        awanMuklisAnswer.frame = CGRect(x: 405, y: 203, width: 154, height: 116)
        awanMuklisAnswer.contentMode = .scaleToFill
        awanMuklisAnswer.alpha = 1
        self.addSubview(awanMuklisAnswer)
        
        
        nextButton.setTitle("Next", for: .normal)
        nextButton.frame = CGRect(x: 300, y: 350, width: 131, height: 44)
        //getStartedButton.center = CGPoint(x: frameWidth/2, y:frameHeight/2)
        nextButton.layer.cornerRadius = 20.0
        nextButton.backgroundColor = UIColor.black
        nextButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        nextButton.layer.shadowOpacity = 0.2
        nextButton.layer.cornerRadius = 20.0
        nextButton.layer.shadowOffset = CGSize(width: 0.0, height: 2.0)
        nextButton.addTarget(self, action: #selector(nextButtonPressed), for: .touchUpInside)
        self.addSubview(nextButton)
        
    }
    
    @objc func nextButtonPressed(_ sender: UIButton?){
        
        nextScreen()
    }

   // button next ke introduction leo 2
  func nextScreen() {
      self.removeFromSuperview()
       let leoasking = leongasihide(scene: self)
      PlaygroundPage.current.liveView = leoasking


        
    }

    
}


