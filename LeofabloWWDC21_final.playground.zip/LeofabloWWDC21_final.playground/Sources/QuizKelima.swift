import Foundation
import UIKit
import PlaygroundSupport
import AVFoundation

public class quizkelima : UIView {
    var frameWidth = 700
    var frameHeight = 500
    
    
    let soalkelima = UIImageView()
    let pertanyaan5 = UILabel()
    let opsibou = UIButton()
    let opsibeb = UIButton()
    let opsiebi = UIButton()
    let quizbackground = UIImageView()
    

    public init(scene: UIView){
        super.init(frame: CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight))
        setupUI()
    }
    
    public required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupUI(){
        
        // background
        quizbackground.image = UIImage(named: "backgroundQuiz.png")
        quizbackground.frame = CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight)
        quizbackground.contentMode = .scaleToFill
        quizbackground.alpha = 1
        self.addSubview(quizbackground)
    
        
        // soal quiz pertama
        soalkelima.image = UIImage(named: "soalquiz5")
        soalkelima.frame = CGRect(x: 95, y: 129, width: 505, height: 69)
        soalkelima.contentMode = .scaleToFill
        soalkelima.alpha = 1
        self.addSubview(soalkelima)
        
        pertanyaan5.text = "Choose the right Answer:"
        pertanyaan5.textColor = UIColor.black
        pertanyaan5.frame = CGRect(x: 263, y: 229, width: 156, height: 26)
        pertanyaan5.font = UIFont(name: "Chela One", size: 18)
        pertanyaan5.alpha = 1
        pertanyaan5.isHidden = false
        self.addSubview(pertanyaan5)
        
        // button paktua
        opsibou.setTitle("Bou", for: .normal)
        opsibou.frame = CGRect(x: 289, y: 281, width: 166, height: 50)
        opsibou.layer.cornerRadius = 20.0
        opsibou.backgroundColor = UIColor.black
        opsibou.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        opsibou.layer.shadowOpacity = 0.2
        opsibou.layer.cornerRadius = 20.0
        opsibou.addTarget(self, action: #selector(nextButtonPressed), for: .touchUpInside)
        self.addSubview(opsibou)
        
        // button elin
        opsiebi.setTitle("Ebi", for: .normal)
        opsiebi.frame = CGRect(x: 289, y: 335, width: 166, height: 50)
        opsiebi.layer.cornerRadius = 20.0
        opsiebi.backgroundColor = UIColor.black
        opsiebi.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        opsiebi.layer.shadowOpacity = 0.2
        opsiebi.layer.cornerRadius = 20.0
        opsiebi.addTarget(self, action: #selector(wrongAnswer(_:)), for: .touchUpInside)
        self.addSubview(opsiebi)
        
        // button sister
        opsibeb.setTitle("Beb", for: .normal)
        opsibeb.frame = CGRect(x: 289, y: 389, width: 166, height: 50)
        opsibeb.layer.cornerRadius = 20.0
        opsibeb.backgroundColor = UIColor.black
        opsibeb.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        opsibeb.layer.shadowOpacity = 0.2
        opsibeb.layer.cornerRadius = 20.0
        opsibeb.addTarget(self, action: #selector(wrongAnswer(_:)), for: .touchUpInside)
        self.addSubview(opsibeb)

        
    }
    func shakeView(vw: UIView) {
        let animation = CAKeyframeAnimation()
        animation.keyPath = "position.x"
        animation.values = [0, 10, -10, 10, -5, 5, -5, 0 ]
        animation.keyTimes = [0, 0.125, 0.25, 0.375, 0.5, 0.625, 0.75, 0.875, 1]
        animation.duration = 0.4
        animation.isAdditive = true
        
        vw.layer.add(animation, forKey: "shake")
    }

    @objc func wrongAnswer(_ sender: UIButton?) {
        UIView.animate(withDuration: 0.5) {
        }
        shakeView(vw: sender!)
    }

    
    @objc func nextButtonPressed(_ sender: UIButton?){
        nextScreen()
    }

   // button next ke introduction leo 2
  func nextScreen() {
      self.removeFromSuperview()
       let quizkelima = congratulation(scene: self)
      PlaygroundPage.current.liveView = quizkelima


        
    }

}


    


