import Foundation
import UIKit
import PlaygroundSupport

public class quizketiga : UIView {
    var frameWidth = 700
    var frameHeight = 500
    
    let soalketiga = UIImageView()
    let pertanyaan3 = UILabel()
    let opsipaktua = UIButton()
    let opsihum = UIButton()
    let opsitulang = UIButton()
    let quizbackground = UIImageView()
    

    public init(scene: UIView){
        super.init(frame: CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight))
        setupUI()
    }
    
    public required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupUI(){
        
        // background
        quizbackground.image = UIImage(named: "backgroundQuiz.png")
        quizbackground.frame = CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight)
        quizbackground.contentMode = .scaleToFill
        quizbackground.alpha = 1
        self.addSubview(quizbackground)
    
        
        // soal quiz pertama
        soalketiga.image = UIImage(named: "soalquiz3")
        soalketiga.frame = CGRect(x: 95, y: 129, width: 505, height: 69)
        soalketiga.contentMode = .scaleToFill
        soalketiga.alpha = 1
        self.addSubview(soalketiga)
        
        pertanyaan3.text = "Choose the right Answer:"
        pertanyaan3.textColor = UIColor.black
        pertanyaan3.frame = CGRect(x: 263, y: 229, width: 156, height: 26)
        pertanyaan3.font = UIFont(name: "Chela One", size: 18)
        pertanyaan3.alpha = 1
        pertanyaan3.isHidden = false
        self.addSubview(pertanyaan3)
        
        // button paktua
        opsipaktua.setTitle("Pak Tua", for: .normal)
        opsipaktua.frame = CGRect(x: 289, y: 281, width: 166, height: 50)
        opsipaktua.layer.cornerRadius = 20.0
        opsipaktua.backgroundColor = UIColor.black
        opsipaktua.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        opsipaktua.layer.shadowOpacity = 0.2
        opsipaktua.layer.cornerRadius = 20.0
        opsipaktua.addTarget(self, action: #selector(nextButtonPressed), for: .touchUpInside)
        self.addSubview(opsipaktua)
        
        // button elin
        opsihum.setTitle("Hum", for: .normal)
        opsihum.frame = CGRect(x: 289, y: 335, width: 166, height: 50)
        opsihum.layer.cornerRadius = 20.0
        opsihum.backgroundColor = UIColor.black
        opsihum.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        opsihum.layer.shadowOpacity = 0.2
        opsihum.layer.cornerRadius = 20.0
        opsihum.addTarget(self, action: #selector(wrongAnswer(_:)), for: .touchUpInside)
        self.addSubview(opsihum)
        
        // button sister
        opsitulang.setTitle("Tulang", for: .normal)
        opsitulang.frame = CGRect(x: 289, y: 389, width: 166, height: 50)
        opsitulang.layer.cornerRadius = 20.0
        opsitulang.backgroundColor = UIColor.black
        opsitulang.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        opsitulang.layer.shadowOpacity = 0.2
        opsitulang.layer.cornerRadius = 20.0
        opsitulang.addTarget(self, action: #selector(wrongAnswer(_:)), for: .touchUpInside)
        self.addSubview(opsitulang)

        
    }
    func shakeView(vw: UIView) {
        let animation = CAKeyframeAnimation()
        animation.keyPath = "position.x"
        animation.values = [0, 10, -10, 10, -5, 5, -5, 0 ]
        animation.keyTimes = [0, 0.125, 0.25, 0.375, 0.5, 0.625, 0.75, 0.875, 1]
        animation.duration = 0.4
        animation.isAdditive = true
        
        vw.layer.add(animation, forKey: "shake")
    }

    @objc func wrongAnswer(_ sender: UIButton?) {
        UIView.animate(withDuration: 0.5) {
        }
        shakeView(vw: sender!)
    }

    
    @objc func nextButtonPressed(_ sender: UIButton?){
        nextScreen()
    }

   // button next ke introduction leo 2
  func nextScreen() {
      self.removeFromSuperview()
       let quizketiga = quizkeempat(scene: self)
      PlaygroundPage.current.liveView = quizketiga


        
    }

}

