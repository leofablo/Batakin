import Foundation
import UIKit
import PlaygroundSupport

public class quizpertama : UIView {
    var frameWidth = 700
    var frameHeight = 500
    
    let soalpertama = UIImageView()
    let pertanyaan = UILabel()
    let opsitulang = UIButton()
    let opsioom = UIButton()
    let quizbackground = UIImageView()
    let nextButton = UIButton()
    
    public init(scene: UIView){
        super.init(frame: CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight))
        setupUI()
    }
    
    public required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupUI(){
        
        // background
        quizbackground.image = UIImage(named: "backgroundQuiz.png")
        quizbackground.frame = CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight)
        quizbackground.contentMode = .scaleToFill
        quizbackground.alpha = 1
        self.addSubview(quizbackground)
    
        
        // soal quiz pertama
        soalpertama.image = UIImage(named: "soalquiz1.png")
        soalpertama.frame = CGRect(x: 98, y: 153, width: 505, height: 69)
        soalpertama.contentMode = .scaleToFill
        soalpertama.alpha = 1
        self.addSubview(soalpertama)
        
        pertanyaan.text = "Choose the right Answer:"
        pertanyaan.textColor = UIColor.black
        pertanyaan.frame = CGRect(x: 272, y: 271, width: 156, height: 26)
        pertanyaan.font = UIFont(name: "Chela One", size: 18)
        pertanyaan.alpha = 1
        pertanyaan.isHidden = false
        self.addSubview(pertanyaan)
        
        // button tulang
        opsitulang.setTitle("Tulang", for: .normal)
        opsitulang.frame = CGRect(x: 159, y: 321, width: 166, height: 50)
        //getStartedButton.center = CGPoint(x: frameWidth/2, y:frameHeight/2)
        opsitulang.layer.cornerRadius = 20.0
        opsitulang.backgroundColor = UIColor.black
        opsitulang.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        opsitulang.layer.shadowOpacity = 0.2
        opsitulang.layer.cornerRadius = 20.0
        opsitulang.addTarget(self, action: #selector(nextButtonPressed), for: .touchUpInside)
        self.addSubview(opsitulang)
        
        // button Oom
        opsioom.setTitle("O'om", for: .normal)
        opsioom.frame = CGRect(x: 356, y: 321, width: 166, height: 50)
        //getStartedButton.center = CGPoint(x: frameWidth/2, y:frameHeight/2)
        opsioom.layer.cornerRadius = 20.0
        opsioom.backgroundColor = UIColor.black
        opsioom.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        opsioom.layer.shadowOpacity = 0.2
        opsioom.layer.cornerRadius = 20.0
        opsioom.addTarget(self, action: #selector(wrongAnswer(_:)), for: .touchUpInside)
        self.addSubview(opsioom)

    }
    
    @objc func nextButtonPressed(_ sender: UIButton?){
        UIView.animate(withDuration: 0.5) {
            self.opsitulang.backgroundColor = .green
        }
        nextScreen()
    }
    
    func shakeView(vw: UIView) {
        let animation = CAKeyframeAnimation()
        animation.keyPath = "position.x"
        animation.values = [0, 10, -10, 10, -5, 5, -5, 0 ]
        animation.keyTimes = [0, 0.125, 0.25, 0.375, 0.5, 0.625, 0.75, 0.875, 1]
        animation.duration = 0.4
        animation.isAdditive = true
        
        vw.layer.add(animation, forKey: "shake")
    }
    
//    @objc func wrongAnswer(_ sender: UIButton?){
//
//        UIView.animate(withDuration: 0.5) {
//            sender.animation
//        }
//    }
    @objc func wrongAnswer(_ sender: UIButton?) {
        UIView.animate(withDuration: 0.5) {
        }
        shakeView(vw: sender!)
    }
   
   // button next ke introduction leo 2
  func nextScreen() {
      self.removeFromSuperview()
       let quizpertama = quizkedua(scene: self)
     PlaygroundPage.current.liveView = quizpertama


        
    }

    
}

//extension UIView {
//    public func shake() {
//          let animation = CAKeyframeAnimation(keyPath: "transform.translation.x")
//          animation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.linear)
//          animation.duration = 0.6
//          animation.values = [-20.0, 20.0, -20.0, 20.0, -10.0, 10.0, -5.0, 5.0, 0.0 ]
//          layer.add(animation, forKey: "shake")
//      }
//}
