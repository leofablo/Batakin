import Foundation
import UIKit
import PlaygroundSupport

public class introleo2 : UIView {
    var frameWidth = 700
    var frameHeight = 500
    
    
    let leocemberut = UIImageView()
    let bulatan = UIImageView()
    let awanleocemberut = UIImageView()
    let nextButton = UIButton()
    
    public init(scene: UIView){
        super.init(frame: CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight))
        setupUI()
    }
    
    public required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupUI(){
        
        // ilustrasi leo 1
        leocemberut.image = UIImage(named: "leocemberut.png")
        leocemberut.frame = CGRect(x: 44, y: 184, width: 256, height: 316)
        leocemberut.contentMode = .scaleToFill
        leocemberut.alpha = 1
        self.addSubview(leocemberut)
        
        
        // bulatan
        bulatan.image = UIImage(named: "bulatan.png")
        bulatan.frame = CGRect(x: 200, y: 192, width: 40, height: 35)
        bulatan.contentMode = .scaleToFill
        bulatan.alpha = 1
        self.addSubview(bulatan)
        
        
        // awan font cemberut
        awanleocemberut.image = UIImage(named: "leoawancemberut.png")
        awanleocemberut.frame = CGRect(x: 300, y: 57, width: 306, height: 230)
        awanleocemberut.contentMode = .scaleToFill
        awanleocemberut.alpha = 1
        self.addSubview(awanleocemberut)
        
        nextButton.setTitle("Next", for: .normal)
        nextButton.frame = CGRect(x: 514, y: 401, width: 131, height: 44)
        //getStartedButton.center = CGPoint(x: frameWidth/2, y:frameHeight/2)
        nextButton.layer.cornerRadius = 20.0
        nextButton.backgroundColor = UIColor.black
        nextButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        nextButton.layer.shadowOpacity = 0.2
        nextButton.layer.cornerRadius = 20.0
        nextButton.layer.shadowOffset = CGSize(width: 0.0, height: 2.0)
        nextButton.addTarget(self, action: #selector(nextButtonPressed), for: .touchUpInside)
        self.addSubview(nextButton)
        
    }
    
    @objc func nextButtonPressed(_ sender: UIButton?){
        
        nextScreen()
    }

   // button next ke introduction leo 2
  func nextScreen() {
      self.removeFromSuperview()
       let introleo2 = intromuklis(scene: self)
      PlaygroundPage.current.liveView = introleo2

        }

    
}


