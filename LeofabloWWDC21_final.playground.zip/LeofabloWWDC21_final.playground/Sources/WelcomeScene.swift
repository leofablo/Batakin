import Foundation
import UIKit
import PlaygroundSupport

public class welcome : UIView {
    var frameWidth = 700
    var frameHeight = 500
    
    
    let getStartedButton = UIButton()
    let gordenImage = UIImageView()
    let welcomeImage = UIImageView()
    
    
    public init(scene: UIView){
        super.init(frame: CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight))
        setupUI()
    }
    
    public required init?(coder: NSCoder) {
        fatalError()
    }
    
    func setupUI(){
        
        // ngasih gorden
        gordenImage.image = UIImage(named: "gordenbackground.png")
        gordenImage.frame = CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight)
        gordenImage.contentMode = .scaleToFill
        gordenImage.alpha = 1
        gordenImage.backgroundColor = UIColor(patternImage: UIImage(named: "gordenbackground.png")!)
        self.addSubview(gordenImage)
        
        
        // ngasih welcome image font
        welcomeImage.image = UIImage(named: "welcomefont.png")
        welcomeImage.frame = CGRect(x: (self.frame.width - 250)/2, y: (self.frame.height - 80)/2, width: 250, height: 80)
        // welcomeImage.center = CGPoint(x: frameWidth/2, y:frameHeight/2)
        welcomeImage.contentMode = .scaleToFill
        self.addSubview(welcomeImage)
      
        
        // ngasih button
        getStartedButton.setTitle("Get Started", for: .normal)
        getStartedButton.frame = CGRect(x: 300, y: 350, width: 131, height: 44)
        //getStartedButton.center = CGPoint(x: frameWidth/2, y:frameHeight/2)
        getStartedButton.layer.cornerRadius = 20.0
        getStartedButton.backgroundColor = UIColor.black
        getStartedButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        getStartedButton.layer.shadowOpacity = 0.2
        getStartedButton.layer.cornerRadius = 20.0
//        getStartedButton.layer.shadowOffset = CGSize(width: 0.0, height: 2.0)
        getStartedButton.addTarget(self, action: #selector(getStartedButtonPressed(_:)), for: .touchUpInside)
//        getStartedButton.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.25).cgColor
        self.addSubview(getStartedButton)
       

    }
    
    @objc func getStartedButtonPressed(_ sender: UIButton?){
        
        nextScreen()
    }
    
    // button next ke introduction leo
    func nextScreen(){
        self.removeFromSuperview()
        let welcomeView = introduction(scene: self)
        PlaygroundPage.current.liveView = welcomeView
    }
    
}

