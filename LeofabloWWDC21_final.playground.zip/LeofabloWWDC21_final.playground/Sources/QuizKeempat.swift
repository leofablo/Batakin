import Foundation
import UIKit
import PlaygroundSupport

public class quizkeempat : UIView {
    var frameWidth = 700
    var frameHeight = 500
    
    let soalkeempat = UIImageView()
    let pertanyaan4 = UILabel()
    let opsitante = UIButton()
    let opsisis = UIButton()
    let quizbackground = UIImageView()
    

    public init(scene: UIView){
        super.init(frame: CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight))
        setupUI()
    }
    
    public required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupUI(){
        
        // background
        quizbackground.image = UIImage(named: "backgroundQuiz.png")
        quizbackground.frame = CGRect(x: 0, y: 0, width: 700, height: 313)
        quizbackground.contentMode = .scaleToFill
        quizbackground.alpha = 1
        self.addSubview(quizbackground)
    
        
        // soal quiz pertama
        soalkeempat.image = UIImage(named: "soalquiz4")
        soalkeempat.frame = CGRect(x: 98, y: 153, width: 505, height: 69)
        soalkeempat.contentMode = .scaleToFill
        soalkeempat.alpha = 1
        self.addSubview(soalkeempat)
        
        pertanyaan4.text = "Choose the right Answer:"
        pertanyaan4.textColor = UIColor.black
        pertanyaan4.frame = CGRect(x: 272, y: 271, width: 156, height: 26)
        pertanyaan4.font = UIFont(name: "Chela One", size: 18)
        pertanyaan4.alpha = 1
        pertanyaan4.isHidden = false
        self.addSubview(pertanyaan4)
        
        // button Tante
        opsitante.setTitle("Tante", for: .normal)
        opsitante.frame = CGRect(x: 159, y: 321, width: 166, height: 50)
        opsitante.layer.cornerRadius = 20.0
        opsitante.backgroundColor = UIColor.black
        opsitante.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        opsitante.layer.shadowOpacity = 0.2
        opsitante.layer.cornerRadius = 20.0
        opsitante.addTarget(self, action: #selector(nextButtonPressed), for: .touchUpInside)
        self.addSubview(opsitante)
        
        // button sis
        opsisis.setTitle("Sis", for: .normal)
        opsisis.frame = CGRect(x: 356, y: 321, width: 166, height: 50)
        opsisis.layer.cornerRadius = 20.0
        opsisis.backgroundColor = UIColor.black
        opsisis.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        opsisis.layer.shadowOpacity = 0.2
        opsisis.layer.cornerRadius = 20.0
        opsisis.addTarget(self, action: #selector(wrongAnswer(_:)), for: .touchUpInside)
        self.addSubview(opsisis)
        
      
    }
    func shakeView(vw: UIView) {
        let animation = CAKeyframeAnimation()
        animation.keyPath = "position.x"
        animation.values = [0, 10, -10, 10, -5, 5, -5, 0 ]
        animation.keyTimes = [0, 0.125, 0.25, 0.375, 0.5, 0.625, 0.75, 0.875, 1]
        animation.duration = 0.4
        animation.isAdditive = true
        
        vw.layer.add(animation, forKey: "shake")
    }

    @objc func wrongAnswer(_ sender: UIButton?) {
        UIView.animate(withDuration: 0.5) {
        }
        shakeView(vw: sender!)
    }
    
    @objc func nextButtonPressed(_ sender: UIButton?){
        
        nextScreen()
    }

   // button next ke introduction leo 2
  func nextScreen() {
      self.removeFromSuperview()
       let quizkeempat = quizkelima(scene: self)
      PlaygroundPage.current.liveView = quizkeempat


        
    }

    
}



