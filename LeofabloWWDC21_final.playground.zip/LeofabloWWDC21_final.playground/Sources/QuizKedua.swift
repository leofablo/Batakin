import Foundation
import UIKit
import PlaygroundSupport

public class quizkedua : UIView {
    var frameWidth = 700
    var frameHeight = 500
    
    let soalkedua = UIImageView()
    let pertanyaan2 = UILabel()
    let opsimaktua = UIButton()
    let opsielin = UIButton()
    let opsisister = UIButton()
    let quizbackground = UIImageView()
    

    public init(scene: UIView){
        super.init(frame: CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight))
        setupUI()
    }
    
    public required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupUI(){
        
        // background
        quizbackground.image = UIImage(named: "backgroundQuiz.png")
        quizbackground.frame = CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight)
        quizbackground.contentMode = .scaleToFill
        quizbackground.alpha = 1
        self.addSubview(quizbackground)
    
        
        // soal quiz pertama
        soalkedua.image = UIImage(named: "soalquiz2.png")
        soalkedua.frame = CGRect(x: 95, y: 129, width: 505, height: 69)
        soalkedua.contentMode = .scaleToFill
        soalkedua.alpha = 1
        self.addSubview(soalkedua)
        
        pertanyaan2.text = "Choose the right Answer:"
        pertanyaan2.textColor = UIColor.black
        pertanyaan2.frame = CGRect(x: 263, y: 229, width: 156, height: 26)
        pertanyaan2.font = UIFont(name: "Chela One", size: 18)
        pertanyaan2.alpha = 1
        pertanyaan2.isHidden = false
        self.addSubview(pertanyaan2)
        
        // button maktua
        opsimaktua.setTitle("Mak Tua", for: .normal)
        opsimaktua.frame = CGRect(x: 289, y: 281, width: 166, height: 50)
        opsimaktua.layer.cornerRadius = 20.0
        opsimaktua.backgroundColor = UIColor.black
        opsimaktua.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        opsimaktua.layer.shadowOpacity = 0.2
        opsimaktua.layer.cornerRadius = 20.0
        opsimaktua.addTarget(self, action: #selector(nextButtonPressed), for: .touchUpInside)
        self.addSubview(opsimaktua)
        
        // button elin
        opsielin.setTitle("Elin", for: .normal)
        opsielin.frame = CGRect(x: 289, y: 335, width: 166, height: 50)
        opsielin.layer.cornerRadius = 20.0
        opsielin.backgroundColor = UIColor.black
        opsielin.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        opsielin.layer.shadowOpacity = 0.2
        opsielin.layer.cornerRadius = 20.0
        opsielin.addTarget(self, action: #selector(wrongAnswer(_:)), for: .touchUpInside)
        self.addSubview(opsielin)
        
        // button sister
        opsisister.setTitle("Sister", for: .normal)
        opsisister.frame = CGRect(x: 289, y: 389, width: 166, height: 50)
        opsisister.layer.cornerRadius = 20.0
        opsisister.backgroundColor = UIColor.black
        opsisister.titleLabel?.font = UIFont.boldSystemFont(ofSize: 18)
        opsisister.layer.shadowOpacity = 0.2
        opsisister.layer.cornerRadius = 20.0
        opsisister.addTarget(self, action: #selector(wrongAnswer(_:)), for: .touchUpInside)
        self.addSubview(opsisister)

        
    }
    
    @objc func nextButtonPressed(_ sender: UIButton?){
        
        nextScreen()
    }
    
    func shakeView(vw: UIView) {
        let animation = CAKeyframeAnimation()
        animation.keyPath = "position.x"
        animation.values = [0, 10, -10, 10, -5, 5, -5, 0 ]
        animation.keyTimes = [0, 0.125, 0.25, 0.375, 0.5, 0.625, 0.75, 0.875, 1]
        animation.duration = 0.4
        animation.isAdditive = true
        
        vw.layer.add(animation, forKey: "shake")
    }

    @objc func wrongAnswer(_ sender: UIButton?) {
        UIView.animate(withDuration: 0.5) {
        }
        shakeView(vw: sender!)
    }

   // button next ke introduction leo 2
  func nextScreen() {
      self.removeFromSuperview()
       let quizkedua = quizketiga(scene: self)
      PlaygroundPage.current.liveView = quizkedua


        
    }

    
}

