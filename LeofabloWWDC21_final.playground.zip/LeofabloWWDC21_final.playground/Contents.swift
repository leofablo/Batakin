
/*:

 ### BATAKIN!
Hello, My name is leo fablo silalahi. I'm 24 years old from Indonesia, My ethnicity is BATAK. I am fascinated by how mobile devices and application influence our daily lives. I started my Ios Development 3 months back, at Apple Developer Academy.

 
 ### Why I have create this Playground?
 Technological advances, many younger generation are distracted by games, social media, etc. younger generation aren't familiar and careless about their culture. I made Batakin playground to help one of these younger generation, my younger brother
    Batak have unique nickname to call their family member, we will play simple quiz on this playground and help my brother get the Batak Emblem at the end.
 
 

### Design: Inspired by https://www.openpeeps.com/
 *  First Scene you will see gorden with Traditional Batak Motif we call that ULOS, Ulos is batak cloth traditional, we use ulos on spescial event like wedding, and more family event.
 *  Characters you will meet one of them leo and muklis, leo as me and my brother as muklis
 *  Monochrome color that I use for make simple but get the point

 
### How To Play?
You will read the short story behind the Batakin Playground, and you just need to click next button for the next page. until you get the quiz choose the right Answer so you can pass to the next page. if you pick the wrong answer the button will shake to give you information pick another one. if you pass all the quiz you will get the Batak Emblem
 
 */
 

import UIKit
import Foundation
import PlaygroundSupport

var view = UIView()
var welcomeView = welcome(scene: view)

PlaygroundPage.current.needsIndefiniteExecution = true
PlaygroundPage.current.liveView = welcomeView



